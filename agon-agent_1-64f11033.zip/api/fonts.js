import supabase from './db-client.js';

const allowed = { ttf: 'font/ttf', otf: 'font/otf', woff: 'font/woff' };

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    if (req.method === 'GET') {
      const { data, error } = await supabase.from('fonts').select('*').order('created_at', { ascending: false });
      if (error) throw error;
      return res.status(200).json(data);
    }
    if (req.method === 'POST') {
      const { name, family, format, fileBase64, fileSize, weightLabel, glyphCount, axes } = req.body || {};
      if (!name || !family || !allowed[format] || typeof fileBase64 !== 'string' || !Number.isFinite(fileSize) || fileSize <= 0 || fileSize > 3 * 1024 * 1024) {
        return res.status(400).json({ error: 'Please upload a valid TTF, OTF, or WOFF font under 3 MB.' });
      }
      const buffer = Buffer.from(fileBase64, 'base64');
      if (buffer.length !== fileSize) return res.status(400).json({ error: 'File data did not match the selected file.' });
      const safeName = String(name).replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 90);
      const storagePath = `${Date.now()}-${Math.random().toString(36).slice(2, 10)}-${safeName}`;
      const { error: uploadError } = await supabase.storage.from('font-files').upload(storagePath, buffer, { contentType: allowed[format], upsert: false });
      if (uploadError) throw uploadError;
      const { data: urlData } = supabase.storage.from('font-files').getPublicUrl(storagePath);
      const { data, error } = await supabase.from('fonts').insert({
        name: String(name).slice(0, 160), family: String(family).slice(0, 160), format,
        file_url: urlData.publicUrl, storage_path: storagePath, file_size: fileSize,
        weight_label: String(weightLabel || 'Regular').slice(0, 80),
        glyph_count: Number.isFinite(glyphCount) ? glyphCount : 0,
        axes: Array.isArray(axes) ? axes : []
      }).select('*').single();
      if (error) {
        await supabase.storage.from('font-files').remove([storagePath]);
        throw error;
      }
      return res.status(201).json(data);
    }
    if (req.method === 'DELETE') {
      const id = Number(req.body?.id);
      if (!Number.isInteger(id) || id < 1) return res.status(400).json({ error: 'Invalid font ID.' });
      const { data: font, error: findError } = await supabase.from('fonts').select('storage_path').eq('id', id).single();
      if (findError) throw findError;
      if (!font.storage_path.startsWith('bundled:')) {
        const { error: removeError } = await supabase.storage.from('font-files').remove([font.storage_path]);
        if (removeError) throw removeError;
      }
      const { error } = await supabase.from('fonts').delete().eq('id', id);
      if (error) throw error;
      return res.status(200).json({ ok: true });
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (err) {
    console.error('Font API error:', err);
    return res.status(500).json({ error: err.message || 'Something went wrong.' });
  }
}
