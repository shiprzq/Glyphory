import { useCallback, useEffect, useRef, useState } from 'react';
import * as opentype from 'opentype.js';
import { ArrowDownToLine, Check, ChevronDown, Copy, FilePlus2, LoaderCircle, RotateCcw, Trash2, X } from 'lucide-react';
import './index.css';

type FontRecord = {
  id: number; name: string; family: string; format: string; file_url: string; storage_path: string;
  file_size: number; weight_label: string; glyph_count: number; axes: Axis[]; created_at: string;
};
type Axis = { tag: string; minValue: number; maxValue: number; defaultValue: number };
type Preset = { id: number; label: string; category: string; text_content: string; script: string; direction: string };
type ParsedFont = ReturnType<typeof opentype.parse>;

function uniqueCharacters(text: string) {
  return [...new Set(Array.from(text).filter(char => !/\s/u.test(char)))];
}
function humanSize(bytes: number) { return bytes < 1024 * 1024 ? `${Math.round(bytes / 1024)} KB` : `${(bytes / 1024 / 1024).toFixed(1)} MB`; }
function familyName(font: FontRecord) { return `glyphory-${font.id}`; }
function fontFormat(format: string) { return format === 'ttf' ? 'truetype' : format === 'otf' ? 'opentype' : 'woff'; }
async function responseData<T>(response: Response): Promise<T> {
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'The request could not be completed.');
  return data as T;
}
function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.onerror = () => reject(new Error('Could not read the font file.'));
    reader.readAsDataURL(file);
  });
}

export default function App() {
  const [fonts, setFonts] = useState<FontRecord[]>([]);
  const [presets, setPresets] = useState<Preset[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [parsed, setParsed] = useState<Record<number, ParsedFont>>({});
  const [fontErrors, setFontErrors] = useState<Record<number, string>>({});
  const [activePreset, setActivePreset] = useState<number | null>(null);
  const [text, setText] = useState('');
  const [fontSize, setFontSize] = useState(44);
  const [weight, setWeight] = useState(400);
  const [lineHeight, setLineHeight] = useState(1.4);
  const [letterSpacing, setLetterSpacing] = useState(0);
  const [axisValues, setAxisValues] = useState<Record<number, Record<string, number>>>({});
  const [darkPaper, setDarkPaper] = useState(false);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [busyId, setBusyId] = useState<number | null>(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [copied, setCopied] = useState(false);
  const [mobileLibrary, setMobileLibrary] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const fetchFonts = useCallback(async () => {
    const data = await responseData<FontRecord[]>(await fetch('/api/fonts'));
    setFonts(data);
    setSelectedIds(previous => previous.length ? previous.filter(id => data.some(font => font.id === id)) : data.slice(0, 2).map(font => font.id));
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [fontData, presetData] = await Promise.all([
          responseData<FontRecord[]>(await fetch('/api/fonts')),
          responseData<Preset[]>(await fetch('/api/presets'))
        ]);
        setFonts(fontData);
        setSelectedIds(fontData.slice(0, 2).map(font => font.id));
        setPresets(presetData);
        if (presetData.length) { setText(presetData[0].text_content); setActivePreset(presetData[0].id); }
      } catch (err) { setError(err instanceof Error ? err.message : 'Could not load the workspace.'); }
      finally { setLoading(false); }
    })();
  }, []);

  useEffect(() => {
    let cancelled = false;
    const registered: string[] = [];
    (async () => {
      for (const font of fonts) {
        try {
          const response = await fetch(font.file_url);
          if (!response.ok) throw new Error('The font file could not be downloaded.');
          const buffer = await response.arrayBuffer();
          const result = opentype.parse(buffer);
          if (cancelled) return;
          setParsed(previous => ({ ...previous, [font.id]: result }));
          const face = new FontFace(familyName(font), buffer, { weight: font.axes.some(axis => axis.tag === 'wght') ? '1 1000' : 'normal' });
          await face.load();
          if (cancelled) return;
          document.fonts.add(face);
          registered.push(familyName(font));
        } catch (err) {
          if (!cancelled) setFontErrors(previous => ({ ...previous, [font.id]: err instanceof Error ? err.message : 'Font unavailable.' }));
        }
      }
    })();
    return () => { cancelled = true; for (const family of registered) { for (const face of document.fonts) if (face.family === family) document.fonts.delete(face); } };
  }, [fonts]);

  const selected = selectedIds.map(id => fonts.find(font => font.id === id)).filter((font): font is FontRecord => !!font);
  const chars = uniqueCharacters(text);
  const currentPreset = presets.find(preset => preset.id === activePreset);
  const direction = currentPreset?.direction === 'rtl' && text === currentPreset.text_content ? 'rtl' : 'auto';
  const activeAxes = selected.flatMap(font => font.axes || []).filter((axis, index, all) => all.findIndex(item => item.tag === axis.tag) === index);
  const cssCode = selected.map(font => `@font-face {\n  font-family: '${font.family.replace(/'/g, "\\'")}';\n  src: url('${font.file_url}') format('${fontFormat(font.format)}');\n  font-style: normal;\n  font-weight: ${font.axes.some(axis => axis.tag === 'wght') ? '100 900' : 'normal'};\n  font-display: swap;\n}`).join('\n\n');

  async function handleFiles(list: FileList | null) {
    if (!list?.length) return;
    setUploading(true); setError(''); setNotice('');
    let uploaded = 0;
    try {
      for (const file of Array.from(list)) {
        const format = file.name.split('.').pop()?.toLowerCase();
        if (!format || !['ttf', 'otf', 'woff'].includes(format)) throw new Error(`${file.name}: only TTF, OTF and WOFF files are supported.`);
        if (file.size > 3 * 1024 * 1024) throw new Error(`${file.name}: font files must be under 3 MB.`);
        const buffer = await file.arrayBuffer();
        let parsedFile: ParsedFont;
        try { parsedFile = opentype.parse(buffer); }
        catch { throw new Error(`${file.name}: the font could not be parsed. Check that the file is valid.`); }
        const rawAxes = (parsedFile.tables as unknown as { fvar?: { axes?: Axis[] } }).fvar?.axes || [];
        const axes = rawAxes.map(axis => ({ tag: axis.tag, minValue: axis.minValue, maxValue: axis.maxValue, defaultValue: axis.defaultValue }));
        const names = parsedFile.names as unknown as Record<string, Record<string, string> | undefined>;
        const family = names.preferredFamily?.en || names.fontFamily?.en || file.name.replace(/\.[^.]+$/, '');
        const weightLabel = names.fontSubfamily?.en || 'Regular';
        const base64 = await fileToBase64(file);
        await responseData<FontRecord>(await fetch('/api/fonts', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
          name: file.name, family, format, fileBase64: base64, fileSize: file.size,
          weightLabel, glyphCount: parsedFile.numGlyphs, axes
        }) }));
        uploaded++;
      }
      await fetchFonts();
      setNotice(`${uploaded} font${uploaded === 1 ? '' : 's'} added to your library.`);
    } catch (err) {
      if (uploaded) await fetchFonts().catch(() => {});
      setError(err instanceof Error ? err.message : 'Upload failed.');
    } finally { setUploading(false); if (fileInput.current) fileInput.current.value = ''; }
  }

  async function deleteFont(font: FontRecord) {
    if (!window.confirm(`Remove ${font.family} from the shared library?`)) return;
    setBusyId(font.id); setError('');
    try {
      await responseData<{ ok: boolean }>(await fetch('/api/fonts', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: font.id }) }));
      await fetchFonts(); setNotice(`${font.family} removed.`);
    } catch (err) { setError(err instanceof Error ? err.message : 'Could not remove font.'); }
    finally { setBusyId(null); }
  }

  function toggleFont(id: number) {
    setSelectedIds(previous => previous.includes(id) ? previous.filter(item => item !== id) : previous.length < 3 ? [...previous, id] : previous);
    setNotice(selectedIds.length >= 3 && !selectedIds.includes(id) ? 'Compare up to three fonts at once.' : '');
  }
  function usePreset(preset: Preset) { setText(preset.text_content); setActivePreset(preset.id); }
  function resetControls() { setFontSize(44); setWeight(400); setLineHeight(1.4); setLetterSpacing(0); setAxisValues({}); setDarkPaper(false); }
  async function copyCss() {
    if (!cssCode) return;
    try { await navigator.clipboard.writeText(cssCode); setCopied(true); window.setTimeout(() => setCopied(false), 2000); }
    catch { setError('Could not copy automatically. Select and copy the CSS below.'); }
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><span className="brand-mark" aria-hidden="true">g<span>.</span></span><span className="brand-name">glyphory</span><span className="brand-divider"/><span className="brand-descriptor">Font coverage studio</span></div>
      <div className="topbar-right"><span className="topbar-status"><span className="status-dot"/> Browser-based glyph analysis</span><button className="top-upload" onClick={() => fileInput.current?.click()} disabled={uploading}><FilePlus2 size={15}/>{uploading ? 'Uploading…' : 'Add fonts'}</button></div>
    </header>
    <input ref={fileInput} type="file" accept=".ttf,.otf,.woff,font/ttf,font/otf,font/woff" multiple hidden onChange={event => handleFiles(event.target.files)} />
    {error && <div className="global-message error-message" role="alert"><span>{error}</span><button aria-label="Dismiss error" onClick={() => setError('')}><X size={16}/></button></div>}
    {notice && <div className="global-message success-message" role="status"><span>{notice}</span><button aria-label="Dismiss notification" onClick={() => setNotice('')}><X size={16}/></button></div>}
    <div className="workspace">
      <aside className={`library-panel ${mobileLibrary ? 'mobile-open' : ''}`}>
        <div className="panel-section-heading"><div><span className="eyebrow">01 / COLLECTION</span><h2>Your fonts <span className="count-pill">{fonts.length}</span></h2></div><button className="mobile-collapse" onClick={() => setMobileLibrary(false)} aria-label="Close library"><X size={18}/></button></div>
        <p className="side-description">Select up to three typefaces to compare their character coverage.</p>
        <button className="dropzone" onClick={() => fileInput.current?.click()} disabled={uploading} onDragOver={event => event.preventDefault()} onDrop={event => { event.preventDefault(); handleFiles(event.dataTransfer.files); }}>
          {uploading ? <LoaderCircle className="spin" size={22}/> : <ArrowDownToLine size={22} strokeWidth={1.5}/>}<span>{uploading ? 'Processing your fonts…' : 'Drop fonts here or browse'}</span><small>TTF, OTF, WOFF · up to 3 MB each</small>
        </button>
        <div className="library-label"><span>LIBRARY</span><span>{fonts.length ? 'SELECT TO COMPARE' : 'EMPTY'}</span></div>
        <div className="font-list">
          {loading ? <div className="sidebar-loading"><LoaderCircle className="spin" size={20}/> Loading library</div> : fonts.length === 0 ? <div className="empty-library"><span className="empty-type">Aa</span><strong>A blank canvas.</strong><p>Add a font to begin testing its glyphs and typography.</p></div> : fonts.map(font => <div className={`font-row ${selectedIds.includes(font.id) ? 'is-selected' : ''}`} key={font.id}>
            <button className="font-select" onClick={() => toggleFont(font.id)} aria-label={`${selectedIds.includes(font.id) ? 'Remove' : 'Add'} ${font.family} ${selectedIds.includes(font.id) ? 'from' : 'to'} comparison`}><span className="selection-box">{selectedIds.includes(font.id) && <Check size={11} strokeWidth={3}/>}</span><span className="font-row-text"><strong>{font.family}</strong><small>{font.weight_label} <span>·</span> {font.format.toUpperCase()}</small></span></button>
            <button className="font-remove" onClick={() => deleteFont(font)} disabled={busyId === font.id} title={`Remove ${font.family}`} aria-label={`Remove ${font.family}`}><Trash2 size={14}/></button>
          </div>)}
        </div>
        <div className="library-footer"><span className="small-spark">✳</span><p>Files are saved to this shared studio. Only upload fonts you have permission to use.</p></div>
      </aside>

      <main className="main-panel">
        <div className="page-heading"><div><span className="eyebrow">THE WORKSPACE / TYPE TESTING</span><h1>See every character<br/><span>in context.</span></h1><p>Compare typefaces, inspect script coverage, and refine the details before they ship.</p></div><div className="heading-index">G / 01</div></div>
        <div className="mobile-library-toggle"><button onClick={() => setMobileLibrary(true)}>Font library <span>{fonts.length}</span><ChevronDown size={16}/></button></div>
        <section className="text-section" aria-labelledby="text-heading"><div className="section-title-row"><div><span className="eyebrow">02 / INPUT</span><h2 id="text-heading">The text</h2></div><span className="section-aside">{chars.length} unique characters</span></div>
          <div className="editor-wrap"><textarea aria-label="Preview text" value={text} onChange={event => { setText(event.target.value); setActivePreset(null); }} placeholder="Type or paste any text to test your fonts…" spellCheck={false}/><div className="editor-bottom"><span>PASTE ANY LANGUAGE OR SCRIPT</span><span>{Array.from(text).length} characters</span></div></div>
          <div className="preset-strip"><span className="preset-label">TRY A SCRIPT</span><div className="preset-buttons">{presets.map(preset => <button key={preset.id} className={`preset-button ${activePreset === preset.id ? 'active' : ''}`} onClick={() => usePreset(preset)} title={preset.category}>{preset.label}</button>)}</div></div>
        </section>
        <section className="preview-section" aria-labelledby="preview-heading"><div className="section-title-row preview-title"><div><span className="eyebrow">03 / COMPARE</span><h2 id="preview-heading">Live specimens</h2></div><span className="section-aside">{selected.length} / 3 selected</span></div>
          <div className={`specimen-grid ${selected.length === 1 ? 'single' : ''}`}>
            {loading ? <div className="preview-empty"><LoaderCircle className="spin" size={25}/> Loading specimens…</div> : selected.length === 0 ? <div className="preview-empty"><span className="preview-empty-mark">Ag</span><h3>Your comparison starts here.</h3><p>Upload a font and select it from your library to see how it handles your text.</p><button onClick={() => fileInput.current?.click()}>Add your first font <span>↗</span></button></div> : selected.map((font, index) => {
              const missing = parsed[font.id] ? chars.filter(char => parsed[font.id].charToGlyphIndex(char) === 0) : [];
              const covered = chars.length - missing.length;
              const settings = Object.entries(axisValues[font.id] || {}).filter(([tag]) => tag !== 'wght').map(([tag, value]) => `'${tag}' ${value}`).join(', ');
              return <article className="specimen" key={font.id}><div className="specimen-top"><div><div className="specimen-number">SPECIMEN {String(index + 1).padStart(2, '0')}</div><h3>{font.family}</h3><span className="specimen-sub">{font.weight_label} <span>·</span> {font.format.toUpperCase()} <span>·</span> {humanSize(font.file_size)}</span></div><span className="specimen-glyph">{font.glyph_count.toLocaleString()} <small>glyphs</small></span></div>
                <div className={`specimen-paper ${darkPaper ? 'paper-dark' : ''}`}><div className="paper-topline"><span>LIVE PREVIEW</span><span>{fontErrors[font.id] ? 'ERROR' : parsed[font.id] ? 'RENDERED' : 'LOADING'}</span></div>{fontErrors[font.id] ? <div className="paper-error">{fontErrors[font.id]}</div> : <div className="preview-text" dir={direction} style={{ fontFamily: `"${familyName(font)}", sans-serif`, fontSize: `${fontSize}px`, fontWeight: weight, lineHeight, letterSpacing: `${letterSpacing}px`, fontVariationSettings: settings || 'normal' }}>{text || 'Your text appears here.'}</div>}<div className="paper-footline"><span>{fontSize} PX</span><span>{weight} WEIGHT</span><span>{letterSpacing.toFixed(1)} TRACKING</span></div></div>
                <div className="specimen-coverage"><div className="coverage-caption"><span>CHARACTER COVERAGE</span><strong>{parsed[font.id] ? `${covered} / ${chars.length}` : 'Checking…'}</strong></div><div className="coverage-track"><span style={{ width: `${parsed[font.id] && chars.length ? covered / chars.length * 100 : 0}%` }}/></div><div className="coverage-note">{!parsed[font.id] ? 'Reading the font’s character map…' : missing.length ? `${missing.length} unsupported unique character${missing.length === 1 ? '' : 's'}` : chars.length ? 'All tested characters supported' : 'Enter text to test character coverage'}</div></div>
              </article>;
            })}
          </div>
        </section>
        <footer className="main-footer"><span>GLYPHORY / FONT COVERAGE STUDIO</span><span>Built for the details that matter.</span></footer>
      </main>

      <aside className="inspector-panel"><div className="inspector-inner"><div className="panel-section-heading"><div><span className="eyebrow">04 / FINE TUNE</span><h2>Inspector</h2></div></div>
        <div className="inspector-group"><div className="group-heading"><span>TYPOGRAPHY</span><button onClick={resetControls} className="reset-button" title="Reset settings"><RotateCcw size={13}/> Reset</button></div>
          <div className="control"><div className="control-label"><label htmlFor="size">Size</label><output>{fontSize} px</output></div><input id="size" type="range" min="16" max="120" value={fontSize} onChange={event => setFontSize(Number(event.target.value))}/><div className="range-ends"><span>16</span><span>120</span></div></div>
          <div className="control"><div className="control-label"><label htmlFor="weight">Weight</label><output>{weight}</output></div><input id="weight" type="range" min="100" max="900" step="100" value={weight} onChange={event => setWeight(Number(event.target.value))}/><div className="range-ends"><span>100</span><span>900</span></div></div>
          <div className="control"><div className="control-label"><label htmlFor="leading">Line height</label><output>{lineHeight.toFixed(2)}</output></div><input id="leading" type="range" min="0.8" max="2.4" step="0.05" value={lineHeight} onChange={event => setLineHeight(Number(event.target.value))}/><div className="range-ends"><span>0.8</span><span>2.4</span></div></div>
          <div className="control"><div className="control-label"><label htmlFor="tracking">Tracking</label><output>{letterSpacing.toFixed(1)} px</output></div><input id="tracking" type="range" min="-3" max="12" step="0.5" value={letterSpacing} onChange={event => setLetterSpacing(Number(event.target.value))}/><div className="range-ends"><span>−3</span><span>12</span></div></div>
          <div className="paper-control"><span>Canvas</span><div className="segmented"><button className={!darkPaper ? 'active' : ''} onClick={() => setDarkPaper(false)}>Light</button><button className={darkPaper ? 'active' : ''} onClick={() => setDarkPaper(true)}>Dark</button></div></div>
        </div>
        {activeAxes.length > 0 && <div className="inspector-group"><div className="group-heading"><span>VARIABLE AXES</span><span className="group-count">{activeAxes.length}</span></div><p className="inspector-hint">Weight is shared with the typography control. Other axes apply to fonts that support them.</p>{activeAxes.map(axis => <div className="control" key={axis.tag}><div className="control-label"><label htmlFor={`axis-${axis.tag}`}>{axis.tag}</label><output>{axis.tag === 'wght' ? weight : axisValues[selected[0]?.id]?.[axis.tag] ?? axis.defaultValue}</output></div><input id={`axis-${axis.tag}`} type="range" min={axis.minValue} max={axis.maxValue} step={(axis.maxValue - axis.minValue) > 20 ? 1 : 0.1} value={axis.tag === 'wght' ? Math.max(axis.minValue, Math.min(axis.maxValue, weight)) : axisValues[selected[0]?.id]?.[axis.tag] ?? axis.defaultValue} onChange={event => axis.tag === 'wght' ? setWeight(Number(event.target.value)) : setAxisValues(previous => Object.fromEntries(selected.map(font => [font.id, { ...previous[font.id], [axis.tag]: Number(event.target.value) }])))} /></div>)}</div>}
        <div className="inspector-group audit-group"><div className="group-heading"><span>GLYPH AUDIT</span><span className="group-count">{chars.length} TESTED</span></div>{selected.length ? selected.map(font => {
          const missing = parsed[font.id] ? chars.filter(char => parsed[font.id].charToGlyphIndex(char) === 0) : [];
          return <div className="audit-font" key={font.id}><div className="audit-font-name"><strong>{font.family}</strong><span className={missing.length ? 'audit-alert' : 'audit-ok'}>{parsed[font.id] ? missing.length ? `${missing.length} missing` : 'Complete' : 'Checking'}</span></div>{parsed[font.id] && missing.length > 0 && <div className="missing-characters" dir="auto">{missing.map((char, index) => <span key={`${char}-${index}`} title={`U+${char.codePointAt(0)?.toString(16).toUpperCase().padStart(4, '0')}`}>{char}</span>)}</div>}</div>;
        }) : <p className="inspector-hint">Select a font to see unsupported characters here.</p>}<p className="audit-disclaimer">Coverage checks the font’s character map. It does not verify shaping or ligature quality.</p></div>
        <div className="inspector-group css-group"><div className="group-heading"><span>CSS EXPORT</span><button className="copy-button" onClick={copyCss} disabled={!cssCode}><Copy size={13}/>{copied ? 'Copied' : 'Copy'}</button></div><pre className="code-block"><code>{cssCode || '/* Select a font to generate your @font-face rules. */'}</code></pre><p className="inspector-hint">Use these rules only with fonts you’re licensed to deploy.</p></div>
      </div></aside>
    </div>
  </div>;
}
